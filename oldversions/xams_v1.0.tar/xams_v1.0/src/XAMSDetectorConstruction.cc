#include <G4Material.hh>
#include <G4NistManager.hh>
#include <G4Box.hh>
#include <G4Tubs.hh>
#include <G4Sphere.hh>
#include <G4Torus.hh>
//#include <G4Orb.hh>
#include <G4Polyhedra.hh>
#include <G4Polycone.hh>
#include <G4Ellipsoid.hh>
//#include <G4Trd.hh>
//#include <G4Cons.hh>
#include <G4UnionSolid.hh>
//#include <G4IntersectionSolid.hh>
#include <G4SubtractionSolid.hh>
#include <G4LogicalVolume.hh>
#include <G4PVPlacement.hh>
#include <G4PVParameterised.hh>
#include <G4OpBoundaryProcess.hh>
#include <G4SDManager.hh>
#include <G4ThreeVector.hh>
#include <G4RotationMatrix.hh>
#include <G4VisAttributes.hh>
#include <G4Colour.hh>
#include <globals.hh>

#include <vector>
#include <numeric>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <cassert>

using std::vector;
using std::stringstream;
using std::max;
 
#include "XAMSDetectorMessenger.hh"

#include "XAMSSensitiveDetector.hh"
#include "XAMSDetectorConstruction.hh"

#include "TFile.h"
#include "TParameter.h"

std::map<G4String, G4double> XAMSDetectorConstruction::m_hGeometryParameters;
 
XAMSDetectorConstruction::XAMSDetectorConstruction()
{
  
  m_pDetectorMessenger = new XAMSDetectorMessenger(this);
  
}

XAMSDetectorConstruction::~XAMSDetectorConstruction()
{
  delete m_pDetectorMessenger;
}

G4VPhysicalVolume*
XAMSDetectorConstruction::Construct()
{
  // enter main detector construction routine
  
  //
  DefineMaterials();
  //
  DefineGeometryParameters();
  //  
  ConstructLaboratory();
  //
  ConstructCrystal(); 
    
  // info  on your geometry
  PrintGeometryInformation();
   
  // write info about geometry to the root output
  MakeDetectorPlots();
  
  return m_pLabPhysicalVolume;
}


void
XAMSDetectorConstruction::DefineMaterials()
{
  G4NistManager* pNistManager = G4NistManager::Instance();
  
  //================================== elements ===================================
  //G4Element *U  = 
  pNistManager->FindOrBuildElement("U");
  G4Element *H  = new G4Element("Hydrogen",  "H",  1.,  1.0079*g/mole);
  G4Element *N  = new G4Element("Nitrogen",  "N",  7.,  14.007*g/mole);
  G4Element *O  = new G4Element("Oxygen",    "O",  8.,  15.999*g/mole);
  G4Element *Na = new G4Element("Sodium",    "Na", 11., 22.989769*g/mole);
  G4Element *I  = new G4Element("Iodine",    "I",  53., 126.904*g/mole);
  G4Element *Cs = new G4Element("Cesium",    "Cs", 55., 132.905*g/mole);
  G4Element *Pb = pNistManager->FindOrBuildElement("Pb");

  //================================== materials ================================== 
  
  //------------------------------------- air -------------------------------------
  pNistManager->FindOrBuildMaterial("G4_AIR");
  
  //----------------------------------- vacuum ------------------------------------
  G4Material *Vacuum = new G4Material("Vacuum", 1.e-20*g/cm3, 2, kStateGas);
  Vacuum->AddElement(N, 0.755);
  Vacuum->AddElement(O, 0.245);
  
  //------------------------------------ water ------------------------
  G4Material *Water = new G4Material("Water", 1.*g/cm3, 2, kStateLiquid);
  Water->AddElement(H, 2);
  Water->AddElement(O, 1);
  
  //------------------------------------ CsI ------------------------
  G4Material *CsI = new G4Material("CsI", 4.51*g/cm3, 2, kStateSolid);
  CsI->AddElement(Cs, 1);
  CsI->AddElement(I , 1);
  //------------------------------------ NaI ------------------------
  G4Material *NaI = new G4Material("NaI", 3.67*g/cm3, 2, kStateSolid);
  NaI->AddElement(Na, 1);
  NaI->AddElement(I , 1);
  
  //------------------------------------ LEAD ------------------------
  G4Material *Lead = new G4Material("Lead", 11.34*g/cm3, 1, kStateSolid);
  Lead->AddElement(Pb,1);

}

void
XAMSDetectorConstruction::DefineGeometryParameters()
{
  //================================== Laboratory =================================
  m_hGeometryParameters["LabHeight"]      = 1.0*m;
  m_hGeometryParameters["LabRadius"]      = 0.5*m;
}

G4double
XAMSDetectorConstruction::GetGeometryParameter(const char *szParameter)
{
  return m_hGeometryParameters[szParameter];
}

void
XAMSDetectorConstruction::ConstructLaboratory()
{
  //================================== Laboratory =================================
  const G4double dLabHalfZ = 0.5*GetGeometryParameter("LabHeight");
  const G4double dLabRadius = GetGeometryParameter("LabRadius");
  
  G4Material *Air = G4Material::GetMaterial("G4_AIR");
  
  G4Tubs *pLabTubs       = new G4Tubs("LabTubs", 0.*cm, dLabRadius, dLabHalfZ, 0.*deg, 360.*deg);
  m_pLabLogicalVolume    = new G4LogicalVolume(pLabTubs, Air, "LabVolume", 0, 0, 0);
  m_pLabPhysicalVolume   = new G4PVPlacement(0, G4ThreeVector(), m_pLabLogicalVolume, "Lab", 0, false, 0);
  m_pMotherLogicalVolume = m_pLabLogicalVolume;
  
  m_pLabLogicalVolume->SetVisAttributes(G4VisAttributes::Invisible);
}

void
XAMSDetectorConstruction::ConstructCrystal()
{
  G4Material *XtalMaterial = G4Material::GetMaterial("CsI");
  
  // simple cylidrical crystal
  G4Tubs *Xtal = new G4Tubs("crystalTubs", 0.*cm, 5*cm, 5*cm, 0.*deg, 360.*deg);
  Xtal_LogicalVolume  = new G4LogicalVolume(Xtal, XtalMaterial, "crystalVolume", 0, 0, 0);
  Xtal_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0,0,0), Xtal_LogicalVolume, "crystal", m_pLabLogicalVolume, false, 0);

  // make sensitive
  G4SDManager *pSDManager = G4SDManager::GetSDMpointer();  
  XAMSSensitiveDetector *pXtalSD = new XAMSSensitiveDetector("XAMS/Xtal");
  pSDManager->AddNewDetector(pXtalSD);
  Xtal_LogicalVolume->SetSensitiveDetector(pXtalSD);
  
  // attributes
  G4Colour hXtalColor(1.,1.,0,0.4);
  
  G4VisAttributes *pXtalVisAtt = new G4VisAttributes(hXtalColor);
  pXtalVisAtt->SetVisibility(true);
  Xtal_LogicalVolume->SetVisAttributes(pXtalVisAtt);
}  

void
XAMSDetectorConstruction::PrintGeometryInformation()
{

}

void XAMSDetectorConstruction::MakeDetectorPlots()
{
  _fGeom = new TFile("geometry.root","RECREATE");
  _detector = _fGeom->mkdir("detector");

  // materials
  MakeMaterialPlots();
  // etc etc
  
  _fGeom->Write();
  _fGeom->Close();
  
}

void XAMSDetectorConstruction::MakeMaterialPlots()
{
  
  // make a list of materials for graphs
  G4int nmaterial = G4Material::GetNumberOfMaterials(); 
  G4cout <<"MakeDetectorPlots:: Number of materials = "<<nmaterial<<G4endl;

  TDirectory *_materials = _detector->mkdir("materials");
  _materials->cd();

  //  for(G4int imat=0; imat<(G4int)matNames.size(); imat++){
  vector<TDirectory*> matdirs;
  

  for(G4int imat=0; imat<nmaterial; imat++){
    G4Material *mat = G4NistManager::Instance()->GetMaterial(imat);
    G4String matname = mat->GetName();
    G4double T   = mat->GetTemperature();
    G4double rho = mat->GetDensity();
    G4double P   = mat->GetPressure();
  
    matdirs.push_back(_materials->mkdir(matname));
    matdirs[imat]->cd();
    TParameter<double> *TemperaturePar = new TParameter<double>("Temperature",T);
    TemperaturePar->Write();
    TParameter<double> *DensityPar     = new TParameter<double>("Density",rho / (g/cm3));
    DensityPar->Write();
    TParameter<double> *PressurePar    = new TParameter<double>("Pressure",P / bar);
    PressurePar->Write();
    // disect the material
    size_t nele = mat->GetNumberOfElements();
    G4ElementVector *elems       = (G4ElementVector*)mat->GetElementVector();
    G4double        *fractionVec = (G4double*)mat->GetFractionVector();

    for(size_t iele=0; iele<nele; iele++){
      G4String elname = (*elems)[iele]->GetName();
      G4double frac   = fractionVec[iele];
//      G4cout <<iele<<" elem = "<<(*elems)[iele]->GetName()<<" f = "<<fractionVec[iele]<<G4endl;
      char  elFrac[100];
      sprintf(elFrac,"f_%s",elname.c_str());
      TParameter<double> *_fracPar = new TParameter<double>((G4String)elFrac,frac);
      _fracPar->Write();
    }
    
    _materials->cd();
  }
  
  _fGeom->cd();
}
