#include <G4ThreeVector.hh>
#include <G4RotationMatrix.hh>
#include <G4ParticleTable.hh>
#include <G4UIdirectory.hh>
#include <G4UIcmdWithoutParameter.hh>
#include <G4UIcmdWithAString.hh>
#include <G4UIcmdWithADoubleAndUnit.hh>
#include <G4UIcmdWith3Vector.hh>
#include <G4UIcmdWith3VectorAndUnit.hh>
#include <G4UIcmdWithAnInteger.hh>
#include <G4UIcmdWithADouble.hh>
#include <G4UIcmdWithABool.hh>
#include <G4Tokenizer.hh>
#include <G4ios.hh>
#include <fstream>
#include <iomanip>

#include "XAMSDetectorMessenger.hh"
#include "XAMSDetectorConstruction.hh"

XAMSDetectorMessenger::XAMSDetectorMessenger(XAMSDetectorConstruction *pXeDetector) 
:m_pXeDetector(pXeDetector)
{ 
	m_pDetectorDir = new G4UIdirectory("/Xe/detector/");
	m_pDetectorDir->SetGuidance("detector control.");
}

XAMSDetectorMessenger::~XAMSDetectorMessenger()
{

  delete m_pDetectorDir;
}

void XAMSDetectorMessenger::SetNewValue(G4UIcommand *pUIcommand, G4String hNewValue)
{

}

//G4String XAMSDetectorMessenger::GetCurrentValue(G4UIcommand *pUIcommand)
//{
//  G4String cv;
//
//	return cv;
//}
		
